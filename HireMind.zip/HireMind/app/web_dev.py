import streamlit as st
from HireMind import HireMind


config={
    'page_title' : "HireMind",
    'page_icon' : '🧠',
    'page_layout' : 'wide',
    'groq_model': 'llama-3.3-70b-versatile',
    'openai_model': 'gpt-4o-mini',
    'radio_opt' : ['GROQ', 'OpenAI']
    }

core=HireMind()
st.set_page_config(
    page_title=config['page_title'],
    page_icon=config['page_icon'],
    layout=config['page_layout']
)

# st.title("HireMind")
selected_opt = st.sidebar.radio(label='Choose the LLM provider', options=config['radio_opt'])

if config['radio_opt'].index(selected_opt) == 1:
    api_key = st.sidebar.text_input(f"Enter your OpenAI API Key", type="password")
else:
    api_key = st.sidebar.text_input(f"Enter your GROQ API Key", type="password")

if config['radio_opt'].index(selected_opt) == 1:
    st.sidebar.text_input("Model (GROQ uses fixed model)", value=config['openai_model'], disabled=True)
    core.load_model(model_name=config['openai_model'], api_key=api_key, openai=True)
else:
    st.sidebar.text_input("Model (OpenAI uses fixed model)", value=config['groq_model'], disabled=True)
    core.load_model(model_name=config['groq_model'], api_key=api_key, openai=False)

if api_key:
    try:
        core.test_model()
    except ValueError as e:
        with st.expander("❌ Model loading failed. Click to view error details."):
            st.error(str(e))
    
    if "resume_uploaded" not in st.session_state or "jd_uploaded" not in st.session_state:
        st.session_state.resume_uploaded = False
        st.session_state.jd_uploaded = False

        if not st.session_state.resume_uploaded or not st.session_state.jd_uploaded:
            uploaded_resume = st.file_uploader("Upload Resume (PDF, DOCX)", type=["pdf", "docx"])
            jd_text = st.text_area("Paste the Job Description here")

        if uploaded_resume and jd_text.strip():
            st.session_state.resume_uploaded = True
            st.session_state.resume_file = uploaded_resume
            st.session_state.jd_text = jd_text
        if st.button("Submit"):
            if not uploaded_resume or not jd_text:
                st.error("Please fill in all the required fields.")
            else:
                st.markdown("## 📊 Resume Analysis")
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("### 🧠 Left Box")
                    st.empty()
                with col2:
                    st.markdown("### 🔍 Right Box")
                    st.empty()
    
    # try:
    #     uploaded_resume = st.file_uploader("Upload Resume (PDF, DOCX)*", type=["pdf", "docx"])
    #     jd_text = st.text_area("Paste the Job Description here*")
    # except Exception as e:
    #     st.error(f"Error uploading resume: {e}")
    
    # if st.button("Submit"):
    #     if not uploaded_resume or not jd_text:
    #         st.error("Please fill in all the required fields.")
    #     else:
    #         st.markdown("## 📊 Resume Analysis")
    #         col1, col2 = st.columns(2)
    #         with col1:
    #             st.markdown("### 🧠 Left Box")
    #             st.empty()  # Placeholder for left content

    #         with col2:
    #             st.markdown("### 🔍 Right Box")
    #             st.empty()  # Placeholder for right content
            # finding_in_resume = core.read_resume(resume_path=uploaded_resume)
            # ai_comments = core.analyse_resume(resume_content=finding_in_resume, jd_content=jd_text)
            # st.subheader("Finding in Resume")
        
# model_options = []

# if api_key:
#     if "GROQ" in api_provider:
#         model_options = ["mixtral-8x7b", "llama3-8b-8192", "gemma-7b-it"]
#     elif "OpenAI" in api_provider:
#         model_options = ["gpt-3.5-turbo", "gpt-4", "gpt-4o"]
#     else:
#         st.warning("Unknown API key type. Please enter a valid GROQ or OpenAI key.")

#     selected_model = st.selectbox("Choose Model", model_options)

# # 3. Upload Resume File
# 

# # 4. Paste JD
# 

# Submit Button

    # else:
        
        # You can add processing logic here
