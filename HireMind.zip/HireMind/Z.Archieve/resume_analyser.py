import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_openai import ChatOpenAI
from langchain_community.document_loaders import PyPDFLoader
from langchain import hub
from langchain_core.output_parsers import JsonOutputParser


class ResumeAnalyser:
    def __init__(self):
        load_dotenv()
        
        self.stropparser=JsonOutputParser() # StrOutputParser()
        os.environ["LANGCHAIN_TRACING_V2"]="true"
        os.environ["LANGSMITH_API_KEY"] = os.getenv("LANGSMITH_API_KEY")
        os.environ["LANGSMITH_ENDPOINT"] = os.getenv("LANGSMITH_ENDPOINT")
        os.environ["LANGSMITH_PROJECT"] = os.getenv("LANGSMITH_PROJECT")
    
    def load_model(self, model_name: str,api_key: str, openai=True, ):
        if openai:
            self.__model = ChatOpenAI(temperature=0, model=model_name, 
                                      max_completion_tokens=500, api_key=api_key)
        else:
            self.__model = ChatGroq(temperature=0.7, model=model_name, 
                                    max_completion_tokens=500, api_key=api_key)
        
        self.__chain = self.prompt | self.__model | self.stropparser
    
    


resume = '''{
  "experience": 6.33,
  "summary": "Aspiring for a challenging career in Software Development with 6 years 4 months of experience in Software Development, J2EE, RPA Blue 
Prism developer, and RPA Business Analyst",
  "skills": {
    "programming_languages": ["Java", "SQL"],
    "j2ee_technologies": ["JSP", "Servlets"],
    "web_technologies": ["HTML", "JavaScript", "Ajax", "JQuery", "XML", "Restful Web Services"],
    "frameworks": ["Spring", "Jdbc"],
    "oracle_technologies": ["Oracle 10g", "SQL"],
    "application_servers": ["Jboss5.x"],
    "tools": ["Eclipse IDE", "SQL Developer", "Blue Prism", "UI Path Orchestrator"],
    "agile_and_sdlc_tools": ["Horizon", "Bitbucket"],
    "other": ["SVN"],
    "testing_frameworks": ["Junit"]
  },
  "projects": [
    {
      "title": "NPD (Non Provisional Data System)",
      "domain": "Banking & Financial Services",
      "environment": "Java Spring, SQL, JSP, Servlets, Java Script, JUnit, JBoss",
      "role": "Developer",
      "team_size": 15,
      "duration": "August 2017 to March 2019"
    },
    {
      "title": "Data Adjustment utility",
      "domain": "Banking & Financial Services",
      "environment": "Java, spring, SQL, JSP, Servlets, Java Script, JUnit, JBoss",
      "role": "Developer",
      "team_size": 15,
      "duration": "August 2017 to March 2019"
    },
    {
      "title": "Remediate to data quality (R2DQ)",
      "domain": "Banking & Financial Services",
      "environment": "Java, Spring, Jdbc, SQL, JSP, Servlets, Java Script, JUnit, JBoss",
      "role": "Developer",
      "team_size": 15,
      "duration": "Aug 2016 to March 2019"
    }'''
    
JD_TEXT_HERE = """
Develop and maintain high-performance applications using Python and related frameworks (Django, Flask, FastAPI).
Build and integrate RESTful APIs with third-party systems to ensure seamless data exchange.
Work with large datasets, utilizing Pandas, NumPy, and other data processing tools.
Automate tasks using Python scripting, Selenium, Airflow, and other automation frameworks.
Ensure code quality through test-driven development (TDD/BDD) and debugging best practices.
Collaborate with Agile teams, participate in code reviews, and follow CI/CD and DevOps best practices.
Optimize system performance, scalability, and reliability.
Good understanding of database management (SQL, NoSQL, MongoDB, Cassandra, Elasticsearch)
Exposure to Gen AI, AI/ML concepts, and visualization tools like QlikSense/Tableau is desirable.
Strong knowledge of OOPs, data structures, and algorithms.
"""


a=ResumeAnalyser()
a.load_model(model_name='llama-3.3-70b-versatile', api_key='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', openai=False)
out = a.analyse_resume(resume_content=resume, jd_content=JD_TEXT_HERE)
print(out)
print(out.keys())
print(out['candidate_fit_score'])
print(type(out))